# Excercise files: 

Open the below files to continue with this excercise: 

- [print_results.py](../data/print_results.py)

- [print_results_hints.py](../data/print_results_hints.py)

