# Excercise files: 

Open the below files to continue with this excercise: 

- [calculates_results_stats.py](../data/calculates_results_stats.py)

- [calculates_results_stats_hints.py](../data/calculates_results_stats_hints.py)

